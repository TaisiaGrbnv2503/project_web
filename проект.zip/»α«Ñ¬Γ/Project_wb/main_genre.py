from data.genres import Genre
from flask import Flask
from data import db_session


app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


def main():
    db_session.global_init("db/film.db")
    session = db_session.create_session()

    gr = Genre()
    gr.genre = 'комедия'
    session.add(gr)

    gr = Genre()
    gr.genre = 'драма'
    session.add(gr)

    gr = Genre()
    gr.genre = 'фэнтези'
    session.add(gr)

    gr = Genre()
    gr.genre = 'романтика'
    session.add(gr)

    gr = Genre()
    gr.genre = 'боевик'
    session.add(gr)

    gr = Genre()
    gr.genre = 'детский'
    session.add(gr)

    gr = Genre()
    gr.genre = 'ужасы'
    session.add(gr)

    gr = Genre()
    gr.genre = 'с'
    session.add(gr)

    session.commit()

if __name__ == '__main__':
    main()