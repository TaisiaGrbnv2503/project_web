from os import abort

from flask import Flask, render_template, redirect, request, make_response, jsonify
from flask_login import LoginManager, login_user, login_required, logout_user
from data.direction import Direction
from data.genres import Genre
from data.actors import Actor
from data.company import Company
from data.films import Film
from PIL import Image
from data.add_direction import AddDirectionForm
from data.add_genre import AddGenreForm
from data.add_company import AddCompanyForm
from data.add_film import AddFilmForm
from data.users import User
from data.register_form import RegisterForm
from data import db_session
from data.login_form import LoginForm



app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'

login_manager = LoginManager()
login_manager.init_app(app)


@app.errorhandler(404)
def not_found(_):
    return make_response(jsonify({'error': 'Not found'}), 404)


@login_manager.user_loader
def load_user(user_id):
    db_sess = db_session.create_session()
    return db_sess.query(User).get(user_id)


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        user = db_sess.query(User).filter(User.email == form.email.data).first()
        if user and user.check_password(form.password.data):
            login_user(user, remember=form.remember_me.data)
            if user.email == 'admin@mail.ru' and user.id == 1:
                return redirect('/index_admin')
            else:
                return redirect("/avt_all_film")
        return render_template('login.html', message="Неверный логин или пароль", form=form)
    return render_template('login.html', title='Авторизация', form=form)


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect("/")


@app.route('/register', methods=['GET', 'POST'])
def reqister():
    form = RegisterForm()
    if form.validate_on_submit():
        if form.password.data != form.password_again.data:
            return render_template('register.html', title='Регистрация', form=form,
                                   message="Пароли не совпадают")
        db_sess = db_session.create_session()
        if db_sess.query(User).filter(User.email == form.email.data).first():
            return render_template('register.html', title='Регистрация', form=form,
                                   message="Такой пользователь уже есть")
        user = User(
            name=form.name.data,
            email=form.email.data,
            about=form.about.data
        )
        user.set_password(form.password.data)
        db_sess.add(user)
        db_sess.commit()
        return redirect('/login')
    return render_template('register.html', title='Регистрация', form=form)


def search_film_all():
    db_sess = db_session.create_session()
    films = db_sess.query(Film).all()
    result = []
    actors = db_sess.query(Actor).all()
    actr_dict = {}
    for el in actors:
        actr_dict[el.id] = el.name_actor
    print(actr_dict)
    genres = db_sess.query(Genre).all()
    gnr_dict = {}
    for el in genres:
        gnr_dict[el.id] = el.genre
    for bk in films:
        ac = bk.id_actor
        ac = ac.split(', ')
        print(type(ac))
        gn = bk.id_genre
        gn = gn.split(', ')
        print(gn)
        act = ''
        for el in ac:
            act += actr_dict[int(el)]
            act += ' '
        dnt = ''
        for el in gn:
            dnt += gnr_dict[int(el)]
            dnt += ' '
        result.append((bk.img_film, bk.direction.surname_direction, bk.direction.name_direction, bk.film_name,
               dnt, act, bk.company.company))

    return result


def search_film_genre(name):
    db_sess = db_session.create_session()
    ft = db_sess.query(Genre).filter(Genre.genre == name).first()
    films = db_sess.query(Film).filter(Film.id_genre == ft.id).all()
    return films


def av_all_film():
    db_sess = db_session.create_session()
    films = db_sess.query(Film).all()
    result = []
    actors = db_sess.query(Actor).all()
    actr_dict = {}
    for el in actors:
        actr_dict[el.id] = el.name_actor
    print(actr_dict)
    genres = db_sess.query(Genre).all()
    gnr_dict = {}
    for el in genres:
        gnr_dict[el.id] = el.genre
    for bk in films:
        ac = bk.id_actor
        ac = ac.split(', ')
        print(type(ac))
        gn = bk.id_genre
        gn = gn.split(', ')
        print(gn)
        act = ''
        for el in ac:
            act += actr_dict[int(el)]
            act += ' '
        dnt = ''
        for el in gn:
            dnt += gnr_dict[int(el)]
            dnt += ' '
        result.append((bk.img_film, bk.direction.surname_direction, bk.direction.name_direction, bk.film_name,
                       bk.company.company, bk.year_of_release, dnt, act))
    return result


@app.route("/")
@app.route("/index")
def index():
    rez = search_film_all()
    return render_template("index.html", rez=rez, title='Главная')


@app.route("/sorting_direction")
def sorting_direction():
    rez = search_film_all()
    rez.sort(key=lambda x: x[1])
    return render_template("index.html", rez=rez, title="Отсортированный список фильмов по фамилии режиссера")


@app.route("/sorting_film_name")
def sorting_film_name():
    rez = search_film_all()
    rez.sort(key=lambda x: x[3])
    return render_template("index.html", rez=rez, title="Отсортированный список фильмов по названию фильма")


@app.route("/avt_all_film")
def avt_all_film():
    films = av_all_film()
    return render_template("avt_film.html", rez=films, title="Все фильмы")


@app.route('/index_admin', methods=['GET', 'POST'])
@login_required
def index_admin():
    return render_template('index_admin.html', title='Страница администратора БД')


@app.route("/avt_comedy")
def avt_comedy():
    return render_template("avt_film.html", rez=search_film_genre('комедия'), title="Комедия")


@app.route("/avt_drama")
def avt_drama():
    return render_template("avt_film.html", rez=search_film_genre("драма"), title="Драма")


@app.route("/avt_fantasy")
def avt_fantasy():
    return render_template("avt_film.html", rez=search_film_genre("фэнтези"), title="Фэнтези")


@app.route("/avt_romantic")
def avt_romantic():
    return render_template("avt_film.html", rez=search_film_genre('романтика'), title="Романтика")


@app.route("/avt_fighter")
def avt_fighter():
    return render_template("avt_film.html", rez=search_film_genre("боевик"), title="Боевик")


@app.route("/avt_kid")
def avt_kid():
    return render_template("avt_film.html", rez=search_film_genre("детский"), title="Детский")


@app.route("/avt_horror")
def avt_horror():
    return render_template("avt_film.html", rez=search_film_genre('ужасы'), title="Ужасы")


@app.route("/avt_adventures")
def avt_adventures():
    return render_template("avt_film.html", rez=search_film_genre("приключения"), title="Приключения")

@app.route('/load_files', methods=['POST', 'GET'])
@login_required
def load_files_img():
    if request.method == 'GET':
        return render_template("load_files.html", title="Загрузка файлов изображений")
    elif request.method == 'POST':
        f = request.files['file']
        with open(f'static/img/{f.filename}', 'wb') as file:
            file.write(f.read())
        img = Image.open(f'static/img/{f.filename}')
        width = 515
        height = 225
        resized_img = img.resize((width, height), Image.ANTIALIAS)
        resized_img.save(f'static/img/{f.filename}')
        return render_template("load_files.html", title="Загрузка файлов изображений")

@app.route('/addfilm', methods=['GET', 'POST'])
@login_required
def addfilm():
    form = AddFilmForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        bk = Film()
        bk.id_direction = form.id_direction.data
        bk.film_name = form.film_name.data
        bk.id_genre = form.id_genre.data
        bk.id_company = form.id_compay.data
        bk.year_of_release = form.year_of_release.data
        bk.content = form.content.data
        bk.id_actor = form.id_actor.data
        bk.img_film = form.img_film.data
        db_sess.add(bk)
        db_sess.commit()
        return redirect('/index_admin')
    return render_template('addfilm.html', title='Добавление фильма', form=form)


@app.route('/edit_film/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_film(id):
    form = AddFilmForm()
    if request.method == "GET":
        db_sess = db_session.create_session()
        bk = db_sess.query(Film).filter(Film.id == id).first()
        if bk:
            form.id_direction.data = bk.id_direction
            form.film_name.data = bk.film_name
            form.id_genre.data = bk.id_genre
            form.id_company.data = bk.id_company
            form.year_of_release.data = bk.year_of_release
            form.content.data = bk.content
            form.id_actor.data = bk.id_actor
            form.img_film.data = bk.img_film
        else:
            abort(404)
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        bk = db_sess.query(Film).filter(Film.id == id).first()
        if bk:
            bk.id_direction = form.id_direction.data
            bk.film_name = form.film_name.data
            bk.id_genre = form.id_genre.data
            bk.id_company = form.id_compay.data
            bk.year_of_release = form.year_of_release.data
            bk.content = form.content.data
            bk.id_actor = form.id_actor.data
            bk.img_film = form.img_film.data
            db_sess.commit()
            return redirect('/index_admin')
        else:
            abort(404)
    return render_template('addfilm.html', title='Редактирование фильма', form=form)


@app.route('/delete_film/<int:id>', methods=['GET', 'POST'])
@login_required
def delete_film(id):
    db_sess = db_session.create_session()
    bk = db_sess.query(Film).filter(Film.id == id).first()
    if bk:
        db_sess.delete(bk)
        db_sess.commit()

    else:
        abort()
    return redirect('/index_admin')


def main():
    db_session.global_init("db/film.db")
    app.run()


if __name__ == '__main__':
    main()