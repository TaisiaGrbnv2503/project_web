from flask_wtf import FlaskForm
from wtforms import SubmitField, StringField, IntegerField, TextAreaField
from wtforms.validators import DataRequired


class AddFilmForm(FlaskForm):
    id_direction = IntegerField('id режиссера', validators=[DataRequired()])
    film_name = StringField('название фильма', validators=[DataRequired()])
    id_genre = IntegerField('id жанра', validators=[DataRequired()])
    id_company = IntegerField('id компании', validators=[DataRequired()])
    year_of_release = IntegerField('год выпуска', validators=[DataRequired()])
    content = TextAreaField("Описание", validators=[DataRequired()])
    id_actor = IntegerField('id актера', validators=[DataRequired()])
    img_film = StringField('название файла', validators=[DataRequired()])

    submit = SubmitField('Сохранить')