import sqlalchemy
from sqlalchemy import orm

from .db_session import SqlAlchemyBase


class Film(SqlAlchemyBase):
    __tablename__ = 'films'

    id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True, autoincrement=True)
    id_direction = sqlalchemy.Column(sqlalchemy.Integer, sqlalchemy.ForeignKey("direction.id"))
    direction = orm.relationship('Direction')
    film_name = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    id_genre = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    #genre = orm.relationship('Genre')
    id_company = sqlalchemy.Column(sqlalchemy.Integer, sqlalchemy.ForeignKey("company.id"))
    company = orm.relationship('Company')
    year_of_release = sqlalchemy.Column(sqlalchemy.Integer, nullable=True, default=0)
    content = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    id_actor = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    #actor = orm.relationship('Actor')
    img_film = sqlalchemy.Column(sqlalchemy.String, nullable=True)

    def __repr__(self):
        return f'<Film> {self.id} {self.film_name}'