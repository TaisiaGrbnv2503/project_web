import sqlalchemy
from sqlalchemy import orm
from .db_session import SqlAlchemyBase


class Company(SqlAlchemyBase):
    __tablename__ = 'company'

    id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True, autoincrement=True)
    company = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    film = orm.relationship("Film", back_populates='company')

    def __repr__(self):
        return f' {self.company}'