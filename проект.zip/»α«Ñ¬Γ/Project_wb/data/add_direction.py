from flask_wtf import FlaskForm
from wtforms import SubmitField, StringField
from wtforms.validators import DataRequired


class AddDirectionForm(FlaskForm):
    name_direction = StringField('Имя режиссера', validators=[DataRequired()])
    surname_direction = StringField('Фамилия режиссера', validators=[DataRequired()])
    submit = SubmitField('Добавить')