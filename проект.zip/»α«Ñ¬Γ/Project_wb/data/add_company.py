from flask_wtf import FlaskForm
from wtforms import SubmitField, StringField
from wtforms.validators import DataRequired


class AddCompanyForm(FlaskForm):
    company = StringField('Компания', validators=[DataRequired()])
    submit = SubmitField('Добавить')