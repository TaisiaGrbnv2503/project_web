import sqlalchemy
from sqlalchemy import orm
from .db_session import SqlAlchemyBase


class Actor(SqlAlchemyBase):
    __tablename__ = 'actor'

    id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True, autoincrement=True)
    name_actor = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    #film = orm.relationship("Film", back_populates='actor')

    def __repr__(self):
        return f'{self.id} {self.name_actor}'