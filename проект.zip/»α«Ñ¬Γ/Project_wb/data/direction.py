import sqlalchemy
from sqlalchemy import orm
from .db_session import SqlAlchemyBase


class Direction(SqlAlchemyBase):
    __tablename__ = 'direction'

    id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True, autoincrement=True)
    name_direction = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    surname_direction = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    film = orm.relationship("Film", back_populates='direction')

    def __repr__(self):
        return f'{self.id} {self.surname_direction} {self.name_direction}'