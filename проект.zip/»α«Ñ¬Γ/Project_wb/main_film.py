from data.direction import Direction
from data.genres import Genre
from data.company import Company
from data.actors import Actor
from data.films import Film
from flask import Flask
from data import db_session

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


def main():
    db_session.global_init("db/film.db")
    session = db_session.create_session()
    bk = Film()
    bk.id_direction = 1
    bk.film_name = 'Стажер'
    bk.id_genre = '1, 2'
    bk.id_company = 1
    bk.year_of_release = 2015
    bk.content = '''Американский комедийный фильм режиссёра Нэнси Мейерс, вышедший на экраны в 2015 году. Впервые фильм был продемонстрирован 15 сентября 2015 года в Бельгии на кинофестивале в Остенде'''
    bk.id_actor = '1, 2'
    bk.img_film = '1.jpg'
    session.add(bk)


    bk = Film()
    bk.id_direction = 2
    bk.film_name = 'Дьявол носит Prada'
    bk.id_genre = '1, 2'
    bk.id_company = 2
    bk.year_of_release = 2006
    bk.content = '''Комедийная драма режиссёра Дэвида Френкеля по одноимённой книге Лорен Вайсбергер, рассказывающая о девушке, попавшей на работу в один из наиболее влиятельных модных журналов.'''
    bk.id_actor = '1, 3'
    bk.img_film = '2.jpg'
    session.add(bk)


    bk = Film()
    bk.id_direction = 3
    bk.film_name = 'Гарри Поттер и философский камень'
    bk.id_genre = '3, 8'
    bk.id_company = 1
    bk.year_of_release = 2001
    bk.content = '''Первый фильм франшизы о мальчике-волшебнике Гарри Поттере, экранизация одноимённого романа Джоан Роулинг'''
    bk.id_actor = '4, 5, 6'
    bk.img_film = '3.jpg'
    session.add(bk)


    bk = Film()
    bk.id_direction = 4
    bk.film_name = "Сумерки"
    bk.id_genre = '4'
    bk.id_company = 3
    bk.year_of_release = 2008
    bk.content = '''Американское романтическое фэнтези режиссёра Кэтрин Хардвик по одноимённому роману Стефани Майер'''
    bk.id_actor = '7, 8'
    bk.img_film = '4.jpg'
    session.add(bk)


    bk = Film()
    bk.id_direction = 5
    bk.film_name = 'Железный человек'
    bk.id_genre = '5'
    bk.id_company = 4
    bk.year_of_release = 2008
    bk.content = '''Американский супергеройский фильм 2008 года режиссёра Джона Фавро с Робертом Дауни-младшим в главной роли'''
    bk.id_actor = '9'
    bk.img_film = '5.jpg'
    session.add(bk)


    bk = Film()
    bk.id_direction = 6
    bk.film_name = 'Чарли и шоколадная фабрика'
    bk.id_genre = '6, 1'
    bk.id_company = 1
    bk.year_of_release = 2005
    bk.content = '''Музыкальный художественный фильм в жанре фэнтези, поставленный режиссёром Тимом Бёртоном по одноимённой повести Роальда Даля.'''
    bk.id_actor = '10, 11'
    bk.img_film = '6.jpg'
    session.add(bk)


    bk = Film()
    bk.id_direction = 7
    bk.film_name = 'Сияние'
    bk.id_genre = '7'
    bk.id_company = 1
    bk.year_of_release = 1980
    bk.content = '''Фильм ужасов режиссёра, сценариста и продюсера Стэнли Кубрика[5], снятый в 1980 году по мотивам одноимённого романа Стивена Кинга.'''
    bk.id_actor = '12'
    bk.img_film = '7.jpg'
    session.add(bk)


    bk = Film()
    bk.id_direction = 8
    bk.film_name = 'Маска'
    bk.id_genre = '1'
    bk.id_company = 5
    bk.year_of_release = 1994
    bk.content = '''Кинокомедия 1994 года, снятая по мотивам одноимённой серии комиксов издательства Dark Horse.'''
    bk.id_actor = '13, 14'
    bk.img_film = '8.jpg'
    session.add(bk)


    bk = Film()
    bk.id_direction = 6
    bk.film_name = 'Алиса в Стране чудес'
    bk.id_genre = '3, 8'
    bk.id_company = 6
    bk.year_of_release = 2010
    bk.content = '''Фильм представляет собой вольное переосмысление сказок Льюиса Кэрролла «Алиса в Стране чудес» и «Алиса в Зазеркалье».'''
    bk.id_actor = '1, 10, 15, 16'
    bk.img_film = '9.jpg'
    session.add(bk)

    session.commit()

if __name__ == '__main__':
    main()


