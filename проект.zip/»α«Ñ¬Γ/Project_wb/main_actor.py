from data.actors import Actor
from flask import Flask
from data import db_session


app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


def main():
    db_session.global_init("db/film.db")
    session = db_session.create_session()

    act = Actor()
    act.name_actor = 'Энн Хэтэуэй'
    session.add(act)

    act = Actor()
    act.name_actor = 'Роберт Де Ниро'
    session.add(act)

    act = Actor()
    act.name_actor = 'Мерил Стрип'
    session.add(act)

    act = Actor()
    act.name_actor = 'Дэниел Рэдклиф'
    session.add(act)

    act = Actor()
    act.name_actor = 'Эмма Уотсон'
    session.add(act)

    act = Actor()
    act.name_actor = 'Руперт Грин'
    session.add(act)

    act = Actor()
    act.name_actor = 'Роберт Паттисон'
    session.add(act)

    act = Actor()
    act.name_actor = 'Кристиан Стюарт'
    session.add(act)

    act = Actor()
    act.name_actor = 'Роберт Дауни мл.'
    session.add(act)

    act = Actor()
    act.name_actor = 'Джонни Депп'
    session.add(act)

    act = Actor()
    act.name_actor = 'Фредди Хаймор'
    session.add(act)

    act = Actor()
    act.name_actor = 'Джек Николсон'
    session.add(act)

    act = Actor()
    act.name_actor = 'Джим Керри'
    session.add(act)

    act = Actor()
    act.name_actor = 'Кемерон Диаз'
    session.add(act)

    act = Actor()
    act.name_actor = 'Миа Васиковска'
    session.add(act)

    act = Actor()
    act.name_actor = 'Хелена Бонэм Картер'
    session.add(act)

    session.commit()

if __name__ == '__main__':
    main()


