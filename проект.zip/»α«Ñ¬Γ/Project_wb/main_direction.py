

from data.direction import Direction
from flask import Flask
from data import db_session


app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


def main():
    db_session.global_init("db/film.db")
    session = db_session.create_session()

    direction = Direction()
    direction.name_direction = 'Нэнси'
    direction.surname_direction = 'Мейерс'
    session.add(direction)

    direction = Direction()
    direction.name_direction = 'Дэвид'
    direction.surname_direction = 'Френкель'
    session.add(direction)

    direction = Direction()
    direction.name_direction = 'Крис'
    direction.surname_direction = 'Коламбус'
    session.add(direction)

    direction = Direction()
    direction.name_direction = 'Кэтрин'
    direction.surname_direction = 'Хардвик'
    session.add(direction)

    direction = Direction()
    direction.name_direction = 'Шейн'
    direction.surname_direction = 'Блэк'
    session.add(direction)

    direction = Direction()
    direction.name_direction = 'Тим'
    direction.surname_direction = 'Бертон'
    session.add(direction)

    direction = Direction()
    direction.name_direction = 'Стенли'
    direction.surname_direction = 'Кубрик'
    session.add(direction)

    direction = Direction()
    direction.name_direction = 'Чак'
    direction.surname_direction = 'Рассел'
    session.add(direction)

    session.commit()

if __name__ == '__main__':
    main()


