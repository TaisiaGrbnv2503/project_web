from data.company import Company

from flask import Flask
from data import db_session


app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


def main():
    db_session.global_init("db/film.db")
    session = db_session.create_session()

    cmp = Company()
    cmp.company = 'Warner Bros. Pictures'
    session.add(cmp)

    cmp = Company()
    cmp.company = '20th Century Fox'
    session.add(cmp)

    cmp = Company()
    cmp.company = 'Summit Entertainment'
    session.add(cmp)

    cmp = Company()
    cmp.company = 'Marvel Studios'
    session.add(cmp)

    cmp = Company()
    cmp.company = 'New Line Cinema'
    session.add(cmp)

    cmp = Company()
    cmp.company = 'Walt Disney Studios'
    session.add(cmp)

    session.commit()

if __name__ == '__main__':
    main()