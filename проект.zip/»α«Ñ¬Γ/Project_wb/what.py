@app.route("/")
@app.route("/index")
def index():
    rez = search_film_all()
    return render_template("index.html", rez=rez, title='Главная')


@app.route("/sorting_direction")
def sorting_author():
    rez = search_film_all()
    rez.sort(key=lambda x: x[1])
    return render_template("index.html", rez=rez, title="Отсортированный список фильмов по фамилии режиссера")


@app.route("/sorting_film_name")
def sorting_book_name():
    rez = search_film_all()
    rez.sort(key=lambda x: x[3])
    return render_template("index.html", rez=rez, title="Отсортированный список фильмов по названию фильма")


@app.route("/avt_all_film")
def avt_all_book():
    db_sess = db_session.create_session()
    films = db_sess.query(Film).all()
    return render_template("avt_film.html", rez=films, title="Все книги")


def main():
    db_session.global_init("db/film.db")
    app.run()


if __name__ == '__main__':
    main()